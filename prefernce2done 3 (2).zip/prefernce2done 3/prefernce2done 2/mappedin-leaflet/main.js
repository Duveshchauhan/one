import * as L from 'leaflet';
import * as GeoJSON from 'geojson';

// Define the styles for the map elements
const styles = {
  building: {
    color: "#BF4320",
    opacity: 0.5,
    fillOpacity: 1,
    fillColor: "#fafafa",
    dashArray: "5 10"
  },
  level: {
    fillColor: "#777",
    fillOpacity: 1,
    color: "black",
    weight: 1
  },
  spaces: (feature) => ({
    color: "black",
    weight: 1,
    opacity: 1,
    fillOpacity: 1,
    fillColor: feature.properties?.color || "white",
  }),
  obstruction: {
    weight: 0,
    fillColor: "black",
    fillOpacity: 1
  },
  node: {
    radius: 2,
    fillColor: "#BF4320",
    color: "#000",
    weight: 1,
    opacity: 1,
    fillOpacity: 0.4
  }
};

// Load the GeoJSON data
async function loadData(filename) {
  const response = await fetch(filename);
  return await response.json();
}

// Load the data files
const levelId = "5835ab589321170c11000000";
const building = await loadData('data/mappedin-demo-mall/building.geojson');
const level = await loadData(`data/mappedin-demo-mall/level/${levelId}.geojson`);
const space = await loadData(`data/mappedin-demo-mall/space/${levelId}.geojson`);
const obstruction = await loadData(`data/mappedin-demo-mall/obstruction/${levelId}.geojson`);
const nodes = await loadData(`data/mappedin-demo-mall/node/${levelId}.geojson`);

// Map the nodes to their coordinates
const nodeMap = new Map();
nodes.features.forEach((feature) => {
  const id = feature.properties.id;
  const coords = feature.geometry.coordinates;
  nodeMap.set(id, L.latLng(coords[1], coords[0]));
});

// Create the node layer
const nodeLayer = L.geoJSON(nodes, {
  pointToLayer: (feature, latlng) => L.circleMarker(latlng, styles.node)
});

// Initialize the map
const map = L.map('map').setView([43.52006516665369, -80.5355190856705], 15);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
L.geoJSON(building, { style: styles.building }).addTo(map);
L.geoJSON(level, { style: styles.level }).addTo(map);
L.geoJSON(obstruction, { style: styles.obstruction }).addTo(map);
L.geoJSON(space, { style: styles.spaces }).addTo(map);
nodeLayer.addTo(map);

// Display the total number of nodes
document.getElementById('nodeCount').innerText = `Total Nodes: ${nodes.features.length}`;

// Variables to store the current path and polyline
let currentPath = null;
let startNode = "n_620bc1ede325471386000015"; // Fixed start node ID
let endNode = null;

// Clear old path and directions
function clearOldPath() {
  if (currentPath) {
    map.removeLayer(currentPath);
    currentPath = null;
  }
  document.getElementById('pathResult').innerText = '';
  document.getElementById('directions').innerText = '';
}

// Dijkstra's Algorithm to find the shortest path
function dijkstra(source, destination) {
  const distances = new Map();
  const previous = new Map();
  const nodesArray = Array.from(nodeMap.keys());

  nodesArray.forEach(node => {
    distances.set(node, Infinity);
    previous.set(node, null);
  });
  distances.set(source, 0);

  while (nodesArray.length > 0) {
    nodesArray.sort((a, b) => distances.get(a) - distances.get(b));
    const closestNode = nodesArray.shift();

    if (closestNode === destination) {
      const path = [];
      let currentNode = destination;
      while (currentNode) {
        path.unshift(currentNode);
        currentNode = previous.get(currentNode);
      }
      return path;
    }

    if (distances.get(closestNode) === Infinity) break;

    const neighbors = getNeighbors(closestNode);
    neighbors.forEach(neighbor => {
      const alt = distances.get(closestNode) + nodeMap.get(closestNode).distanceTo(nodeMap.get(neighbor));
      if (alt < distances.get(neighbor)) {
        distances.set(neighbor, alt);
        previous.set(neighbor, closestNode);
      }
    });
  }
  return null;
}

// Get the neighbors of a node
function getNeighbors(node) {
  const neighbors = [];
  nodes.features.forEach((feature) => {
    if (feature.properties.id === node) {
      feature.properties.neighbors.forEach((neighbor) => {
        if (nodeMap.has(neighbor)) {
          neighbors.push(neighbor);
        }
      });
    }
  });
  return neighbors;
}

// Generate directions from a path
function generateDirections(path) {
  const directions = [];

  for (let i = 1; i < path.length; i++) {
    const previousNode = nodeMap.get(path[i - 1]);
    const currentNode = nodeMap.get(path[i]);

    if (previousNode && currentNode) {
      const angle = Math.atan2(
        currentNode.lat - previousNode.lat,
        currentNode.lng - previousNode.lng
      );

      const direction = angle > -Math.PI / 4 && angle <= Math.PI / 4 ? "Go straight" :
        angle > Math.PI / 4 && angle <= 3 * Math.PI / 4 ? "Turn right" :
        angle > -3 * Math.PI / 4 && angle <= -Math.PI / 4 ? "Turn left" : "Make a U-turn";

      directions.push(direction);
    }
  }

  return directions;
}

// Handle find path click
function handleFindPath() {
  if (!endNode) {
    document.getElementById('pathResult').innerText = 'Please select an end node by clicking on the map';
    return;
  }

  clearOldPath();

  const sourceNode = startNode;
  const destinationNode = endNode;

  const sourceLatLng = nodeMap.get(sourceNode);
  const destinationLatLng = nodeMap.get(destinationNode);

  if (!sourceLatLng || !destinationLatLng) {
    document.getElementById('pathResult').innerText = 'Invalid node IDs';
    return;
  }

  const path = dijkstra(sourceNode, destinationNode);
  if (path) {
    const latlngs = path.map(node => nodeMap.get(node));
    currentPath = L.polyline(latlngs, { color: 'red' }).addTo(map);

    const distance = latlngs.reduce((acc, latlng, i, arr) => {
      if (i === 0) return acc;
      return acc + arr[i - 1].distanceTo(latlng);
    }, 0).toFixed(2);
    document.getElementById('pathResult').innerText = `Shortest Path Distance: ${distance} meters`;

    const directions = generateDirections(path);
    const directionsList = directions.map((step, index) => `<li>${step}</li>`).join('');
    document.getElementById('directions').innerHTML = `<ol>${directionsList}</ol>`;
  } else {
    document.getElementById('pathResult').innerText = 'No path found';
    document.getElementById('directions').innerText = '';
  }
}

// Handle map click to select the end node
map.on('click', (e) => {
  if (endNode === null) {
    const endLatLng = e.latlng;
    endNode = getNearestNode(endLatLng);

    if (endNode) {
      document.getElementById('destination').value = endNode;
      handleFindPath();
    } else {
      document.getElementById('pathResult').innerText = 'No nearby node found for the selected location.';
    }
  } else {
    startNode = endNode;
    const newEndLatLng = e.latlng;
    endNode = getNearestNode(newEndLatLng);

    if (endNode) {
      document.getElementById('destination').value = endNode;
      handleFindPath();
    } else {
      document.getElementById('pathResult').innerText = 'No nearby node found for the selected location.';
    }
  }
});

function getNearestNode(latlng) {
  let nearestNode = null;
  let nearestDistance = Infinity;

  nodeMap.forEach((nodeLatLng, nodeId) => {
    const distance = latlng.distanceTo(nodeLatLng);
    if (distance < nearestDistance) {
      nearestDistance = distance;
      nearestNode = nodeId;
    }
  });

  return nearestNode;
}

