import * as L from 'leaflet';
import * as GeoJSON from 'geojson';
import 'leaflet/dist/leaflet.css';

// Define the styles for various map elements
const styles = {
  building: {
    color: "#BF4320",
    opacity: 0.5,
    fillOpacity: 1,
    fillColor: "#fafafa",
    dashArray: "5 10"
  },
  level: {
    fillColor: "#777",
    fillOpacity: 1,
    color: "black",
    weight: 1
  },
  spaces: (feature: any) => {
    return {
      color: "black",
      weight: 1,
      opacity: 1,
      fillOpacity: 1,
      fillColor: feature.properties!.color || "white",
    };
  },
  obstruction: {
    weight: 0,
    fillColor: "black",
    fillOpacity: 1
  },
  node: {
    radius: 2,
    fillColor: "#BF4320",
    color: "#000",
    weight: 1,
    opacity: 1,
    fillOpacity: 0.4
  },
  path: {
    color: "#BF4320",
    weight: 2,
    opacity: 0.7
  }
};

// Function to load data asynchronously
async function loadData(filename: string) {
  return (await fetch(`${filename}`)).json();
}

const levelId = "5835ab589321170c11000000";

// Load the GeoJSON data for the building, level, space, obstruction, and nodes
const building = await loadData('data/mappedin-demo-mall/building.geojson') as GeoJSON.FeatureCollection;
const level = await loadData(`data/mappedin-demo-mall/level/${levelId}.geojson`) as GeoJSON.FeatureCollection;
const space = await loadData(`data/mappedin-demo-mall/space/${levelId}.geojson`) as GeoJSON.FeatureCollection;
const obstruction = await loadData(`data/mappedin-demo-mall/obstruction/${levelId}.geojson`) as GeoJSON.FeatureCollection;
const nodes = await loadData(`data/mappedin-demo-mall/node/${levelId}.geojson`) as GeoJSON.FeatureCollection;

// Log the nodes data to inspect it
console.log(nodes);

// Create layers for the building, level, obstruction, space, and nodes
const buildingLayer = L.geoJSON(building, {
  style: styles.building
});

const map = L.map('map', {
  maxBounds: buildingLayer.getBounds(),
});

map.fitBounds(buildingLayer.getBounds());

const levelLayer = L.geoJSON(level, { style: styles.level });
const obstructionLayer = L.geoJSON(obstruction, { style: styles.obstruction });

const spaceLayer = L.geoJSON(space, {
  style: styles.spaces,
  filter: (feature) => {
    return feature.geometry.type === "Polygon";
  }
});

const nodeLayer = L.geoJSON(nodes, {
  pointToLayer: (feature, latlng) => {
    return L.circleMarker(latlng, styles.node);
  }
});

// Create a layer for paths between nodes
const paths: L.LatLngTuple[][] = [];
nodes.features.forEach((node) => {
  const { coordinates } = node.geometry;
  const { neighbors } = node.properties;
  neighbors.forEach((neighborId: string) => {
    const neighbor = nodes.features.find((n) => n.properties.id === neighborId);
    if (neighbor) {
      const neighborCoordinates = neighbor.geometry.coordinates;
      paths.push([
        [coordinates[1], coordinates[0]],
        [neighborCoordinates[1], neighborCoordinates[0]]
      ]);
    }
  });
});

const pathLayer = L.layerGroup(
  paths.map((path) => L.polyline(path, styles.path))
);

// Add the layers to the map
buildingLayer.addTo(map);
levelLayer.addTo(map);
obstructionLayer.addTo(map);
spaceLayer.addTo(map);
nodeLayer.addTo(map);
pathLayer.addTo(map);

// Define the nodes data structure
interface NodeProperties {
  id: string;
  level: string;
  neighbors: string[];
  weight: number;
  multiplier: number;
  accessible: boolean;
  externalId: string | null;
}

interface NodeFeature {
  type: string;
  geometry: {
    type: string;
    coordinates: [number, number];
  };
  properties: NodeProperties;
}

interface NodesData {
  type: string;
  features: NodeFeature[];
}

// Function to find the path between two nodes
function findPath(startId: string, endId: string): [number, number][] {
  const startNode = nodes.features.find(n => n.properties.id === startId);
  const endNode = nodes.features.find(n => n.properties.id === endId);

  if (!startNode || !endNode) {
    console.error("Start or End node not found.");
    return [];
  }

  const queue: NodeFeature[] = [startNode];
  const visited: Set<string> = new Set();
  const cameFrom: Map<string, string> = new Map();

  visited.add(startId);

  while (queue.length > 0) {
    const currentNode = queue.shift()!;
    const { neighbors } = currentNode.properties;

    if (currentNode.properties.id === endId) {
      break;
    }

    neighbors.forEach(neighborId => {
      if (!visited.has(neighborId)) {
        const neighborNode = nodes.features.find(n => n.properties.id === neighborId);
        if (neighborNode) {
          queue.push(neighborNode);
          visited.add(neighborId);
          cameFrom.set(neighborId, currentNode.properties.id);
        }
      }
    });
  }

  const path: [number, number][] = [];
  let currentNode = endNode;
  while (currentNode) {
    path.unshift([currentNode.geometry.coordinates[1], currentNode.geometry.coordinates[0]]);
    currentNode = nodes.features.find(n => n.properties.id === cameFrom.get(currentNode.properties.id));
  }

  return path;
}

// Function to calculate the distance of the path
function calculatePathDistance(path: [number, number][]): number {
  let distance = 0;
  for (let i = 1; i < path.length; i++) {
    distance += map.distance(path[i - 1], path[i]);
  }
  return distance;
}

// Variables to store the start and end node IDs
let startNodeId: string | null = null;
let endNodeId: string | null = null;

// Add click event to set start and end nodes
map.on('click', (e) => {
  const clickedLatLng = e.latlng;
  let closestNode: NodeFeature | null = null;
  let minDistance = Infinity;

  nodes.features.forEach((node) => {
    const nodeLatLng = L.latLng(node.geometry.coordinates[1], node.geometry.coordinates[0]);
    const distance = clickedLatLng.distanceTo(nodeLatLng);
    if (distance < minDistance) {
      closestNode = node;
      minDistance = distance;
    }
  });

  if (closestNode) {
    if (!startNodeId) {
      startNodeId = closestNode.properties.id;
      L.circleMarker(L.latLng(closestNode.geometry.coordinates[1], closestNode.geometry.coordinates[0]), {
        radius: 6,
        fillColor: 'green',
        color: 'black',
        weight: 1,
        fillOpacity: 1
      }).addTo(map).bindPopup('Start Node').openPopup();
    } else if (!endNodeId) {
      endNodeId = closestNode.properties.id;
      L.circleMarker(L.latLng(closestNode.geometry.coordinates[1], closestNode.geometry.coordinates[0]), {
        radius: 6,
        fillColor: 'red',
        color: 'black',
        weight: 1,
        fillOpacity: 1
      }).addTo(map).bindPopup('End Node').openPopup();

      // Find and display the path
      const path = findPath(startNodeId, endNodeId);
      if (path.length > 0) {
        const route = L.polyline(path, { color: 'blue', weight: 4 }).addTo(map);
        map.fitBounds(route.getBounds());

        // Calculate and display the distance
        const distance = calculatePathDistance(path);
        console.log(`Shortest path distance: ${distance.toFixed(2)} meters`);
       // console.log('start node',startNodeId);
        // Create a tooltip or popup to display the distance on the map
        L.popup()
          .setLatLng(path[Math.floor(path.length / 2)])
        
          .setContent(`Shortest path distance: ${distance.toFixed(2)} meters , start node:${startNodeId},End node: ${endNodeId}`)
          .openOn(map);
      }
    }
  }
});
