import * as L from 'leaflet';
import * as GeoJSON from 'geojson';

// Define the styles for the map elements
const styles = {
  building: {
    color: "#BF4320",
    opacity: 0.5,
    fillOpacity: 1,
    fillColor: "#fafafa",
    dashArray: "5 10"
  },
  level: {
    fillColor: "#777",
    fillOpacity: 1,
    color: "black",
    weight: 1
  },
  spaces: (feature: any) => ({
    color: "black",
    weight: 1,
    opacity: 1,
    fillOpacity: 1,
    fillColor: feature.properties?.color || "white",
  }),
  obstruction: {
    weight: 0,
    fillColor: "black",
    fillOpacity: 1
  },
  node: {
    radius: 2,
    fillColor: "#BF4320",
    color: "#000",
    weight: 1,
    opacity: 1,
    fillOpacity: 0.4
  }
};

// Load the GeoJSON data
async function loadData(filename: string) {
  return (await fetch(filename)).json();
}

// Load the data files
const levelId = "5835ab589321170c11000000";
const building = await loadData('data/mappedin-demo-mall/building.geojson') as GeoJSON.FeatureCollection;
const level = await loadData(`data/mappedin-demo-mall/level/${levelId}.geojson`) as GeoJSON.FeatureCollection;
const space = await loadData(`data/mappedin-demo-mall/space/${levelId}.geojson`) as GeoJSON.FeatureCollection;
const obstruction = await loadData(`data/mappedin-demo-mall/obstruction/${levelId}.geojson`) as GeoJSON.FeatureCollection;
const nodes = await loadData(`data/mappedin-demo-mall/node/${levelId}.geojson`) as GeoJSON.FeatureCollection;

// Map the nodes to their coordinates
const nodeMap = new Map<string, L.LatLng>();
nodes.features.forEach((feature: any) => {
  const id = feature.properties.id;
  const coords = feature.geometry.coordinates;
  nodeMap.set(id, L.latLng(coords[1], coords[0]));
});

// Create the node layer
const nodeLayer = L.geoJSON(nodes, {
  pointToLayer: (feature, latlng) => L.circleMarker(latlng, styles.node)
});

// Initialize the map
const map = L.map('map').setView([43.52006516665369, -80.5355190856705], 15);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
L.geoJSON(building, { style: styles.building }).addTo(map);
L.geoJSON(level, { style: styles.level }).addTo(map);
L.geoJSON(obstruction, { style: styles.obstruction }).addTo(map);
L.geoJSON(space, { style: styles.spaces }).addTo(map);
nodeLayer.addTo(map);

// Display the total number of nodes
document.getElementById('nodeCount')!.innerText = `Total Nodes: ${nodes.features.length}`;

// Dijkstra's Algorithm to find the shortest path
function dijkstra(source: string, destination: string) {
  const distances = new Map<string, number>();
  const previous = new Map<string, string | null>();
  const nodes = Array.from(nodeMap.keys());

  nodes.forEach(node => {
    distances.set(node, Infinity);
    previous.set(node, null);
  });
  distances.set(source, 0);

  while (nodes.length > 0) {
    nodes.sort((a, b) => (distances.get(a)! - distances.get(b)!));
    const closestNode = nodes.shift();

    if (closestNode === destination) {
      const path = [];
      let currentNode = destination;
      while (currentNode) {
        path.unshift(currentNode);
        currentNode = previous.get(currentNode)!;
      }
      return path;
    }

    if (distances.get(closestNode!) === Infinity) {
      break;
    }

    const neighbors = getNeighbors(closestNode!);
    neighbors.forEach(neighbor => {
      const alt = distances.get(closestNode!)! + nodeMap.get(closestNode!)!.distanceTo(nodeMap.get(neighbor)!);
      if (alt < distances.get(neighbor)!) {
        distances.set(neighbor, alt);
        previous.set(neighbor, closestNode!);
      }
    });
  }

  return null;
}

// Get the neighbors of a node
function getNeighbors(node: string) {
  const neighbors: string[] = [];
  nodes.features.forEach((feature: any) => {
    if (feature.properties.id === node) {
      feature.properties.neighbors.forEach((neighbor: string) => {
        if (nodeMap.has(neighbor)) {
          neighbors.push(neighbor);
        }
      });
    }
  });
  return neighbors;
}

// Find the shortest path and display it
document.getElementById('findPath')!.addEventListener('click', () => {
  const sourceNode = (document.getElementById('source') as HTMLInputElement).value;
  const destinationNode = (document.getElementById('destination') as HTMLInputElement).value;

  const sourceLatLng = nodeMap.get(sourceNode);
  const destinationLatLng = nodeMap.get(destinationNode);

  if (!sourceLatLng || !destinationLatLng) {
    document.getElementById('pathResult')!.innerText = 'Invalid node IDs';
    return;
  }

  const path = dijkstra(sourceNode, destinationNode);
  if (path) {
    const latlngs = path.map(node => nodeMap.get(node)!);
    L.polyline(latlngs, { color: 'red' }).addTo(map);

    const distance = latlngs.reduce((acc, latlng, i, arr) => {
      if (i === 0) return acc;
      return acc + arr[i - 1].distanceTo(latlng);
    }, 0).toFixed(2);
    document.getElementById('pathResult')!.innerText = `Shortest Path Distance: ${distance} meters`;
  } else {
    document.getElementById('pathResult')!.innerText = 'No path found';
  }
});

// Define the fixed start node
const fixedStartNode = "n_620bc1ede325471386000015"; // Replace with actual fixed start node ID
map.on('click', (e) => {
  const endLatLng = e.latlng;
  const nearestEndNode = getNearestNode(endLatLng);

  if (nearestEndNode) {
    (document.getElementById('destination') as HTMLInputElement).value = nearestEndNode;
    const path = dijkstra(fixedStartNode, nearestEndNode);

    if (path) {
      const latlngs = path.map(node => nodeMap.get(node)!);
      L.polyline(latlngs, { color: 'red' }).addTo(map);

      const distance = latlngs.reduce((acc, latlng, i, arr) => {
        if (i === 0) return acc;
        return acc + arr[i - 1].distanceTo(latlng);
      }, 0).toFixed(2);
      document.getElementById('pathResult')!.innerText = `Shortest Path Distance: ${distance} meters`;
    } else {
      document.getElementById('pathResult')!.innerText = 'No path found';
    }
  }
});

// Get the nearest node to a clicked location
function getNearestNode(latlng: L.LatLng) {
  let nearestNode: string | null = null;
  let minDistance = Infinity;

  nodeMap.forEach((value, key) => {
    const distance = value.distanceTo(latlng);
    if (distance < minDistance) {
      minDistance = distance;
      nearestNode = key;
    }
  });

  return nearestNode;
}
